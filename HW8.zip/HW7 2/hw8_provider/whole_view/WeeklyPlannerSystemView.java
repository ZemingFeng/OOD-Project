package cs3500.weeklyplanner.view.hw06;

import java.util.Objects;

import javax.swing.JFrame;

import cs3500.weeklyplanner.model.MutablePlannerModel;
import cs3500.weeklyplanner.model.ReadOnlyPlannerModel;

/**
 * The main view for WeeklyPlannerSystem.
 */
public class WeeklyPlannerSystemView extends JFrame implements PlannerSystemView {
  private ReadOnlyPlannerModel model;
  private MainFrame mainFrame;


  /**
   * Constructor for WeeklyPlannerSystemView.
   *
   * @param model is the model.
   */
  public WeeklyPlannerSystemView(MutablePlannerModel model) {
    this.model = Objects.requireNonNull(model);
    this.mainFrame = new JMainFrameView(model);
  }

  @Override
  public MainFrame getMainFrame() {
    return mainFrame;
  }

}
