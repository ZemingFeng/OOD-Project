package cs3500.weeklyplanner.view.hw06;

import java.awt.event.ActionListener;

import cs3500.weeklyplanner.controller.Features;
import cs3500.weeklyplanner.model.IUser;
import cs3500.weeklyplanner.model.Schedule;

/**
 * Main frame.
 * for grading, please ignore this for now.
 */
public interface MainFrame {
  /**
   * sets the listener of the main frame.
   * @param listener is the listener.
   */
  void setListener(Features listener);

  /**
   * observes the event frame of the system.
   * @return the event frame.
   */
  EventFrame getEventFrame();

  /**
   * renders the system's state.
   */
  void repaintAll();
}
