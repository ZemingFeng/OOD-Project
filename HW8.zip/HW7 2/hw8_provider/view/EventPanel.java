package cs3500.weeklyplanner.view.hw06;

/**
 * Event Panel interface.
 * for grading, please ignore this for now.
 */
public interface EventPanel {
  // may require methods in the future.
}
