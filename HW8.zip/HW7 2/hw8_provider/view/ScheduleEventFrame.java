package cs3500.weeklyplanner.view.hw06;

/**
 * interface specifically for scheduling event.
 */
public interface ScheduleEventFrame {
  //may require methods in the future.
}
