package cs3500.weeklyplanner.view.hw06;

import java.util.List;


import cs3500.weeklyplanner.controller.Features;
import cs3500.weeklyplanner.model.Date;
import cs3500.weeklyplanner.model.IUser;

/**
 * Event Frame interface. Represents an Event frame.
 * for grading, please ignore this for now.
 */
public interface EventFrame {
  /**
   * sets the listener.
   * @param listener is the listener.
   */
  void setListener(Features listener);

  /**
   * observes the name of the event.
   * @return the String that represents the event.
   */
  String getEventName();

  /**
   * observes the location of the event.
   * @return the name of the location.
   */
  String getLocationName();

  /**
   * observes the online information of the event.
   * @return a boolean telling whether the event is online or not.
   */
  boolean getOnline();

  /**
   * observes the invitees of the event.
   * @return a list of IUser representing the invitees.
   */
  List<IUser> getInvitees();

  /**
   * observes the starting day of the event.
   * @return the starting Date.
   */
  Date getStartingDate();

  /**
   * observes the starting time of the event.
   * @return the starting time.
   */
  int getStartingTime();

  /**
   * observes the ending day of the event.
   * @return the ending date.
   */
  Date getEndingDay();

  /**
   * observes the ending time of the event.
   * @return the ending time.
   */
  int getEndingTime();

  /**
   * observes the host of the event.
   * @return the host.
   */
  IUser getHost();

  /**
   * draws the layout.
   */
  void drawLayout();

  /**
   * observes the duration of the event to be scheduled.
   * @return a duration in minutes.
   */
  int getDuration();

  /**
   * observes whether the event happens only in work days or any time.
   * @return the boolean.
   */
  boolean getAnyTime();
}
