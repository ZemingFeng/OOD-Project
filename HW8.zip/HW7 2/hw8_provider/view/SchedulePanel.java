package cs3500.weeklyplanner.view.hw06;


import cs3500.weeklyplanner.model.IUser;

/**
 * schedule panel interface.
 * for grading, please ignore this for now.
 */
public interface SchedulePanel {

  /**
   * change the selected user of the system.
   * @param user is the user to be changed.
   */
  void changeSelectedUser(IUser user);

}
