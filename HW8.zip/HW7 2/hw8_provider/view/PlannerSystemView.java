package cs3500.weeklyplanner.view.hw06;

import java.awt.event.ActionListener;

/**
 * The main view interface of the planner system.
 */
public interface PlannerSystemView {
  /**
   * observes the main frame of the system.
   * @return the main frame.
   */
  MainFrame getMainFrame();

}
