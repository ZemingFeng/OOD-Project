package cs3500.weeklyplanner.controller;

import java.util.List;

import cs3500.weeklyplanner.model.Date;
import cs3500.weeklyplanner.model.IEvent;
import cs3500.weeklyplanner.model.IUser;

/**
 * Features class.
 */
public interface Features {
  /**
   * creates the event.
   * @param name is the name
   * @param online is the online
   * @param location is location
   * @param startingDay is starting date
   * @param startingTime is starting time
   * @param endingDay is ending day
   * @param endingTime is ending time
   * @param host is the host
   * @param invitees is the invitees
   */
  void createEvent(String name, boolean online, String location, Date startingDay, int startingTime,
                   Date endingDay, int endingTime, IUser host, List<IUser> invitees);

  void modifyEvent(IEvent oldEvent, IEvent newEvent);

  void scheduleEvent(String name, String location, boolean online, int duration, IUser host,
                     List<IUser> invitees, boolean anyTime);

  void removeEvent(IEvent event);
}
