package cs3500.weeklyplanner.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import cs3500.weeklyplanner.model.Date;
import cs3500.weeklyplanner.model.Event;
import cs3500.weeklyplanner.model.IEvent;
import cs3500.weeklyplanner.model.IUser;
import cs3500.weeklyplanner.model.MutablePlannerModel;
import cs3500.weeklyplanner.view.hw06.PlannerSystemView;

/**
 * Controller for the Planner System. Controls the model and the view.
 */
public class WeeklyPlannerController implements Features, ActionListener {
  private MutablePlannerModel model;
  private PlannerSystemView view;

  /**
   * Constructor for the WeeklyPlannerController.
   * @param model is the model.
   * @param view is the view.
   */
  public WeeklyPlannerController(MutablePlannerModel model, PlannerSystemView view) {
    this.model = model;
    this.view = view;
    view.getMainFrame().setListener(this);
  }

  @Override
  public void actionPerformed(ActionEvent e) {
    switch (e.getActionCommand()) {
      case "createEvent":
        this.createEvent(view.getMainFrame().getEventFrame().getEventName(),
                view.getMainFrame().getEventFrame().getOnline(),
                view.getMainFrame().getEventFrame().getLocationName(),
                view.getMainFrame().getEventFrame().getStartingDate(),
                view.getMainFrame().getEventFrame().getStartingTime(),
                view.getMainFrame().getEventFrame().getEndingDay(),
                view.getMainFrame().getEventFrame().getEndingTime(),
                view.getMainFrame().getEventFrame().getHost(),
                view.getMainFrame().getEventFrame().getInvitees());
        break;
      case "removeEvent":
        break;
      case "modifyEvent":
        break;
      case "scheduleEvent":
        model.scheduleEvent(
                view.getMainFrame().getEventFrame().getEventName(),
                view.getMainFrame().getEventFrame().getLocationName(),
                view.getMainFrame().getEventFrame().getOnline(),
                view.getMainFrame().getEventFrame().getDuration(),
                view.getMainFrame().getEventFrame().getHost(),
                view.getMainFrame().getEventFrame().getInvitees(),
                view.getMainFrame().getEventFrame().getAnyTime()
        );
        break;
      default:
        throw new IllegalArgumentException("invalid operation");
    }
  }

  @Override
  public void createEvent(String name, boolean online, String location,
                          Date startingDay, int startingTime, Date endingDay,
                          int endingTime, IUser host, List<IUser> invitees) {
    IEvent event = new Event(name, online, location, startingDay, startingTime,
            endingDay, endingTime, host, invitees);
    model.createEvent(event);
    model.loadEvent(event);
    view.getMainFrame().repaintAll();
  }

  @Override
  public void modifyEvent(IEvent oldEvent, IEvent newEvent) {
    //don't have enough time to implement.
  }

  @Override
  public void scheduleEvent(String name, String location, boolean online,
                            int duration, IUser host, List<IUser> invitees, boolean anyTime) {
  //don't have enough time to implement.
  }

  @Override
  public void removeEvent(IEvent event) {
    //don't have enough time to implement.
  }
}
