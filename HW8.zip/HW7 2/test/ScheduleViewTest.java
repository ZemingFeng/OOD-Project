import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import cs3500.weeklyplanner.model.Date;
import cs3500.weeklyplanner.model.Event;
import cs3500.weeklyplanner.model.Schedule;
import cs3500.weeklyplanner.model.User;
import cs3500.weeklyplanner.model.WeeklyPlannerModel;
import cs3500.weeklyplanner.view.hw05.ScheduleTextView;

/**
 * test class for the view.
 */
public class ScheduleViewTest {
  ArrayList noEvent;
  Event event1;
  Event event2;
  Event event3;
  Event oodLecture;
  Event cal2Lecture;
  Schedule scheduleActual;
  Schedule adamSchedule;
  Schedule user2Schedule;
  WeeklyPlannerModel plannerModel1;
  User user1;
  User user2;
  User adam;
  ScheduleTextView view;

  @Before
  public void init() {
    noEvent = new ArrayList<>();

    scheduleActual = new Schedule(new ArrayList<>());
    user2Schedule = new Schedule(new ArrayList<>());
    adamSchedule = new Schedule(new ArrayList<>());
    user1 = new User("user1", scheduleActual);
    user2 = new User("user2", user2Schedule);
    adam = new User("Adam Li", adamSchedule);
    event1 = new Event("event1", false, "b",
            Date.Monday, 900, Date.Tuesday, 900, user2, List.of(user1, user2));
    event2 = new Event("event2", false, "b",
            Date.Monday, 800, Date.Tuesday, 900, user2, List.of(user1, user2));
    event3 = new Event("event3", false, "b",
            Date.Wednesday, 800, Date.Thursday, 905, user2, List.of(user1, user2));
    oodLecture = new Event("OOD", false, "Snell", Date.Tuesday,
            1335, Date.Tuesday, 1515, user1, List.of(adam, user1));
    cal2Lecture = new Event("Cal2", false, "Cargill", Date.Monday,
            1030, Date.Monday, 1135, user1, List.of(adam, user1));

    plannerModel1 = new WeeklyPlannerModel(List.of(user1, user2, adam), new ArrayList<>());

    view = new ScheduleTextView(plannerModel1);

  }

  @Test
  public void testView() {
    plannerModel1.createEvent(event1);
    System.out.println(view.toString());
    Assert.assertEquals(view.toString(), "User: user1\n" +
            "Sunday: \n" +
            "Monday: \n" +
            "        name:event1\n" +
            "        time:Monday: 900 -> Tuesday: 900\n" +
            "        location: b\n" +
            "        online: false\n" +
            "        invitees: user1\n" +
            "        user2\n" +
            "Tuesday: \n" +
            "Wednesday: \n" +
            "Thursday: \n" +
            "Friday: \n" +
            "Saturday: \n" +
            "User: user2\n" +
            "Sunday: \n" +
            "Monday: \n" +
            "        name:event1\n" +
            "        time:Monday: 900 -> Tuesday: 900\n" +
            "        location: b\n" +
            "        online: false\n" +
            "        invitees: user1\n" +
            "        user2\n" +
            "Tuesday: \n" +
            "Wednesday: \n" +
            "Thursday: \n" +
            "Friday: \n" +
            "Saturday: \n" +
            "User: Adam Li\n" +
            "Sunday: \n" +
            "Monday: \n" +
            "Tuesday: \n" +
            "Wednesday: \n" +
            "Thursday: \n" +
            "Friday: \n" +
            "Saturday: \n");
  }
}
