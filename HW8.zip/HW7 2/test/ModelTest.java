import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.xml.sax.SAXException;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;


import cs3500.weeklyplanner.model.Date;
import cs3500.weeklyplanner.model.Event;
import cs3500.weeklyplanner.model.IEvent;
import cs3500.weeklyplanner.model.ISchedule;
import cs3500.weeklyplanner.model.IUser;
import cs3500.weeklyplanner.model.MutablePlannerModel;
import cs3500.weeklyplanner.model.ReadOnlyPlannerModel;
import cs3500.weeklyplanner.model.Schedule;
import cs3500.weeklyplanner.model.User;
import cs3500.weeklyplanner.model.WeeklyPlannerModel;
import cs3500.weeklyplanner.xmlutils.XMLUtil;
import cs3500.weeklyplanner.xmlutils.XMLUtils;


/**
 * test class for the planner model.
 */
public class ModelTest {
  ArrayList noEvent;
  IEvent event1;
  IEvent event2;
  IEvent event3;
  IEvent oodLecture;
  IEvent cal2Lecture;
  ISchedule scheduleActual;
  ISchedule adamSchedule;
  ISchedule user2Schedule;
  MutablePlannerModel plannerModel1;
  IUser user1;
  IUser user2;
  IUser adam;
  XMLUtils utils;

  @Before
  public void init() {
    noEvent = new ArrayList<>();

    scheduleActual = new Schedule(new ArrayList<>());
    user2Schedule = new Schedule(new ArrayList<>());
    adamSchedule = new Schedule(new ArrayList<>());
    user1 = new User("user1", scheduleActual);
    user2 = new User("user2", user2Schedule);
    adam = new User("Adam Li", adamSchedule);
    event1 = new Event("event1", false, "b",
            Date.Monday, 900, Date.Tuesday, 900, user2, List.of(user1, user2));
    event2 = new Event("event2", false, "b",
            Date.Monday, 800, Date.Tuesday, 900, user2, List.of(user1, user2));
    event3 = new Event("event3", false, "b",
            Date.Wednesday, 800, Date.Thursday, 905, user2, List.of(user1, user2));
    oodLecture = new Event("OOD", false, "Snell", Date.Tuesday,
            1335, Date.Tuesday, 1515, user1, List.of(adam, user1));
    cal2Lecture = new Event("Cal2", false, "Cargill", Date.Monday,
            1030, Date.Monday, 1135, user1, List.of(adam, user1));

    plannerModel1 = new WeeklyPlannerModel(List.of(user1, user2, adam), new ArrayList<>());

    utils = new XMLUtil(plannerModel1);

  }

  @Test(expected = IllegalArgumentException.class)
  public void testUserCons() {
    User badUser = new User(null, null);
  }

  @Test
  public void testSelect() {
    Schedule scheduleExpected = new Schedule(noEvent);
    Assert.assertEquals(scheduleExpected, plannerModel1.select(user1));
    Assert.assertEquals(adamSchedule, plannerModel1.select(adam));

  }

  @Test
  public void testCreate() {
    plannerModel1.createEvent(event1);
    Assert.assertEquals(plannerModel1.getLoadedEvents(), List.of(event1));
    plannerModel1.createEvent(event2);
    Assert.assertEquals(List.of(event1, event2),
            plannerModel1.getLoadedEvents());
  }

  @Test
  public void testCreateEventWithDetail() {
    Event csLecture = new Event("CSlecture", false, "Cargill097", Date.Friday, 1030,
            Date.Friday, 1135, user1, List.of(user1, adam));
    plannerModel1.createEvent("CSlecture", false, "Cargill097", Date.Friday, 1030,
            Date.Friday, 1135, user1, List.of(user1, adam));
    Assert.assertEquals(plannerModel1.getLoadedEvents(), List.of(csLecture));
  }

  @Test(expected = IllegalStateException.class)
  public void testBadCreateState() {
    plannerModel1.createEvent(event1);
    plannerModel1.createEvent(event1);

  }

  @Test(expected = IllegalArgumentException.class)
  public void testBadCreateArguments() {
    plannerModel1.createEvent(null);
  }

  @Test
  public void testModify() {
    plannerModel1.createEvent(event1);
    plannerModel1.modifyEvent(event1, event2);
    Assert.assertEquals(plannerModel1.getLoadedEvents(), List.of(event2));
  }

  @Test(expected = IllegalStateException.class)
  public void testBadModifyState() {
    plannerModel1.modifyEvent(event1, event1);
    plannerModel1.modifyEvent(event2, event1);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testBadModifyArguments() {
    plannerModel1.modifyEvent(null, null);
  }

  @Test
  public void testRemove() {
    plannerModel1.createEvent(event1);
    plannerModel1.removeEvent(event1);
    Assert.assertNotEquals(plannerModel1.seeEvents(
            Date.Monday, 900, Date.Monday, 901, user1), List.of(event1));
  }

  @Test(expected = IllegalStateException.class)
  public void testBadRemoveState() {
    plannerModel1.removeEvent(event2);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testBadRemoveArguments() {
    plannerModel1.removeEvent(null);
  }

  @Test
  public void testScheduleEvent() {
    List<IUser> users = new ArrayList<>();
    users.add(user1);
    users.add(user2);
    plannerModel1.createEvent(event1);
    plannerModel1.createEvent(event2);
    Assert.assertEquals(plannerModel1.seeEvents(
            Date.Wednesday, 900, Date.Wednesday, 901, user1), List.of(event3));
    Assert.assertEquals(plannerModel1.seeEvents(
            Date.Wednesday, 900, Date.Wednesday, 901, user1), List.of(event3));
  }

  @Test(expected = IllegalStateException.class)
  public void testBadScheduleState() {
    plannerModel1.createEvent(event1);
    plannerModel1.createEvent(event2);
  }

  @Test
  public void testSeeEvent() {
    plannerModel1.createEvent(event1);
    Assert.assertEquals(plannerModel1.seeEvents(
            Date.Monday, 900, Date.Monday, 901, user1), List.of(event1));

  }

  @Test(expected = IllegalStateException.class)
  public void testBadSeeEventState() {
    plannerModel1.seeEvents(
            Date.Monday, 900, Date.Monday, 900, user1);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testBadSeeEventArguments() {
    plannerModel1.seeEvents(
            null, 900, Date.Monday, 900, user1);

  }

  @Test
  public void testIsOverlap() {
    List<IEvent> events = List.of(event1, event3);
    Assert.assertEquals(false, scheduleActual.isOverlap(events));
    System.out.println(plannerModel1.getUsers().toString());
  }

  @Test
  public void testSave() throws ParserConfigurationException, TransformerException {
    plannerModel1.createEvent(event1);
    utils.saveSchedule();
    Assert.assertEquals(plannerModel1.getLoadedEvents(), List.of(event1));
  }

  @Test
  public void testUploadXML() throws ParserConfigurationException, IOException, SAXException {
    utils.uploadXML("/Users/lhc/Desktop/OOD/group/HW5/schedules/user1_schedule.xml");
    Assert.assertEquals(plannerModel1.getUsers(), List.of(user1, user2, adam));
  }

  @Test
  public void testOverlapV1() {
    Assert.assertEquals(1,1);
    ISchedule schedule1 = new Schedule(new ArrayList<>());
    ISchedule schedule2 = new Schedule(new ArrayList<>());
    IUser user1 = new User("user1", schedule1);
    IUser user2 = new User("user2", schedule2);
    IEvent newEvent1 = new Event("event1", false, "location", Date.Monday, 900,
            Date.Monday, 1000, user1, List.of(user1, user2));
    IEvent newEvent2 = new Event("event2", false, "location", Date.Tuesday, 924,
            Date.Tuesday, 1357, user1, List.of(user1));
    IEvent newEvent3 = new Event("event3", false, "location", Date.Wednesday, 1145,
            Date.Wednesday, 1322, user1, List.of(user1, user2));
    MutablePlannerModel model = new WeeklyPlannerModel(List.of(user1, user2), List.of());
  }

}
