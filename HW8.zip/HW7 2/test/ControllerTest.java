/**
 * the test class for controllers.
 */
public class ControllerTest {
    // not enough time left.
}
