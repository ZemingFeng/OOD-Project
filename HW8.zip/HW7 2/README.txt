Overview: 
Our codebase builds a weekly planner system for multiple users. The system can visualize every users’ plan in text view. Users can create, modify, delete or schedules events to the system. In later version we will create a GUI view for this system. Class invariant: the maximum length of Minutes is 60 minutes.

Quick start:
//quick setup
ISchedule schedule1 = new Schedule(new ArrayList<>());
IUser user1 = new User("user1", schedule1);
PlannerModel plannerModel1 = new WeeklyPlannerModel(List.of(user1), new ArrayList<>());

//upload and modify events
event1 = new Event("event1", false, "Northeastern",
        Date.Monday, 900, Date.Tuesday, 900, user1, List.of(user1));
event2 = new Event("event2", false, "Boston",
        Date.Monday, 800, Date.Tuesday, 900, user1, List.of(user1));
plannerModel1.createEvent(event1); //load the event to the system
plannerModel1.scheduleEvent(event1); //automatically schedule the event to its invitees’ schedule
plannerModel1.modifyEvent(event1, event2); //modify the event1 to event2
plannerModel1.removeEvent(event2); //remove event2

//Save and display
plannerModel1.saveSchedule(); //save the all users’ schedules to xml files in schedule folder
ScheduleView view = new scheduleTextView(plannerModel1); 
System.out.println(view.toString); //print out all schedules in text view

Key components: 
PlannerModel: handle the whole data in the system. Allows people to create, modify, delete events and upload a schedule or save schedules for xml files. 
ScheduleView: handle the view of the system. From now it print out the schedules as text view but later we will change it to a GUI view. 
XMLUtils: handle or the transformation from xml file to data, or from data to xml files. 

Key subcomponents: 
User: represents users’ schedules loaded in the system. Contains a name and a schedule. 
Schedule: act as events holder for users. Contains a list of events. 
Event: the basic event in the system. Contains all the information a event should have: name, online or not, location, start day, end day, start time, end time, host, invitees. 
Date: a enum class representing the 7 weekdays in a week from Sunday to Saturday. Each assigned a value from 1 to 7 so that this is helpful for checking overlap for events. 
EventFrame: draws the event frame. We used GroupLayout to manage the layout of different components. We designed all the JButtons, JComboBoxes, etc. following the instructions. The "create event" button successfully prints out the message.
MainFrame: draws the main frame. We override the paintComponent() method to draw the grid and all the events as red rectangles together. We have a helper method that is specifically designed to draw events, which is called in the paintComponent() method. Inside the helper, we also setup Rectangle to keep track of the events' 2D positions. We mapped the Events to their corresponding Rectangle, make it easier to track whether the user has clicked on an event or not.

Source Organization: 
  /+-Model
	/+-MutablePlannerModel
	/+-ReadOnlyPlannerModel
	/+-WeeklyPlannerModel
	/+-User
	/+-Schedule
	/+-Event
	/+-Date
  /+-View
	/+-hw05
		/+-ScheduleTextView
	/+-hw06
		/+-EventFrame
		/+-EventPanel
		/+-JEventFrameView
		/+-JFileChooserFrame
		/+-JMainFrameView
		/+-JSchedulePanel
		/+-MainFrame
		/+-SchedulePanel
		/+-JScheduleEventFrameView
		/+-WeeklyPlannerSystemView
  /+-XMLUtils
	/+-XMLUtil
	/+-XMLUtils
/+-PlannerRunner
  /+-Controller
	/+-Features
	/+-WeeklyPlannerController

Update for part 2:
1. Added a class invariant to the system, which limits the maximum Minutes to be 60 minutes. Made this change since we forgot to add class invariant last time.
2. Added some new getter methods, such as getUser(), getOnline(), getHost(). Those are the getter methods that we didn't use last time so we didn't notice that they were not added. 
3. Changed the name of the interface PlannerModel to MutablePlannerModel, and added a new interface called ReadOnlyPlannerModel, following the instruction of the assignment.
4. Implemented 4 new interfaces and 4 classes that implements them. All interfaces named "...Frame" is to draw the corresponding frames. All interfaces named "...Panel" is to draw the corresponding panels. We sat the ActionListener in the panel class since it made it easier for data retrieving and image drawing.
5. Added a main runner class called PlannerRunner.

Update for part 3:
1. Redesign the schedule method in the model. Now that there is a helper method called loadEvent did the old schedules method's job. The new schedule know create an event in the first available duration for all the invitees of the event.
2. A new frame of schedule is also added to show all the information and input field that for a schedule method, also allow user to schedule the event. 
3. A high level view class and interface are added, which only takes in a model. This view is passed to the controller. 
4. A Features interface is added, basically contains all the actions we want to implement in it. 5. Controller is added, which implements the methods in the Features. 
6. Some action listener were added in the view so that they can communicate with controller. 